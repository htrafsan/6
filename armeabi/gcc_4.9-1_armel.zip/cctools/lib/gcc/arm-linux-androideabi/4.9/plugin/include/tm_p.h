#ifndef GCC_TM_P_H
#define GCC_TM_P_H
#ifdef IN_GCC
# include "config/arm/arm-protos.h"
# include "config/arm/aarch-common-protos.h"
# include "config/linux-protos.h"
# include "tm-preds.h"
#endif
#endif /* GCC_TM_P_H */
