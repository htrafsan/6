/*	$OpenBSD: setjmp.h,v 1.2 2004/08/10 21:10:56 pefo Exp $	*/

/* Public domain */

#ifndef _MIPS_SETJMP_H_
#define _MIPS_SETJMP_H_

#define	_JBLEN	157		/* size, in longs, of a jmp_buf */

#endif /* !_MIPS_SETJMP_H_ */
